// background.js — mantido mínimo (storage agora é acessado diretamente pelos content scripts)
console.log('[JuliomaqSF] background.js iniciado');
