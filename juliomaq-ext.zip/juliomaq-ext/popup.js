var LABELS = {
  tipoRegistro: 'Tipo de Registro',
  subTipo:      'Sub Tipos Serviços Oficina',
  origem:       'Origem',
  status:       'Status',
  conta:        'Nome da Conta',
  contato:      'Nome do Contato',
  ativo:        'Ativo',
  serie:        'Nº Série Topper',
  descMaquina:  'Descrição Máquina',
  operador:     'Nome do Operador',
  assunto:      'Assunto',
  reclamacao:   'Reclamação do Cliente'
};

var SF_URL = 'https://stara.my.site.com/concessionariasrevendas/s/case/Case/Default';

function formatBloco(d){
  return Object.keys(LABELS).filter(function(k){ return d[k]; })
    .map(function(k){ return LABELS[k]+': '+d[k]; })
    .join('\n');
}

function timeSince(ts){
  var s = Math.floor((Date.now()-ts)/1000);
  if(s<60) return s+'s atrás';
  if(s<3600) return Math.floor(s/60)+'min atrás';
  return Math.floor(s/3600)+'h atrás';
}

function setMsg(txt, cls){
  var el = document.getElementById('msg');
  if(!el) return;
  el.textContent = txt;
  el.className = 'msg '+(cls||'');
}

chrome.storage.local.get(['sfData','sfTs'], function(r){
  var body = document.getElementById('body');
  var hSub = document.getElementById('hSub');

  if(!r.sfData || !r.sfTs){
    hSub.textContent = 'Sem dados pendentes';
    body.innerHTML = '<div class="empty">🔍 Nenhum caso preparado.<br><br>Abra o Juliomaq, clique em <b>☁️ Caso SF</b> numa atividade e depois em <b>🚀 Abrir SF e Salvar</b>.</div>';
    return;
  }

  var expired = (Date.now()-r.sfTs) > 15*60*1000;
  if(expired){
    hSub.textContent = 'Dados expirados';
    body.innerHTML = '<div class="empty">⏰ Os dados expiraram (mais de 15 min).<br>Gere novamente no Juliomaq.</div>';
    chrome.storage.local.remove(['sfData','sfTs']);
    return;
  }

  var d = r.sfData;
  var bloco = formatBloco(d);
  hSub.textContent = 'Caso preparado · ' + timeSince(r.sfTs);

  body.innerHTML =
    '<div class="block" id="bloco">'+bloco+'</div>'+
    '<div class="ts" id="ts">Válido por '+ Math.ceil((15*60*1000-(Date.now()-r.sfTs))/60000) +'min</div>'+
    '<div class="btns">'+
      '<button class="btn btn-copy" id="btnCopy">📋 Copiar Tudo</button>'+
      '<button class="btn btn-fill" id="btnFill">✏️ Preencher SF</button>'+
    '</div>'+
    '<div class="msg" id="msg"></div>';

  // Copiar
  document.getElementById('btnCopy').onclick = function(){
    navigator.clipboard.writeText(bloco).then(function(){
      setMsg('✅ Copiado!','ok');
      setTimeout(function(){ setMsg(''); },2000);
    });
  };

  // Preencher — injeta content-sf.js na aba ativa do SF
  document.getElementById('btnFill').onclick = function(){
    var btn = document.getElementById('btnFill');
    btn.disabled = true;
    setMsg('Procurando aba do SF...','inf');

    chrome.tabs.query({}, function(tabs){
      var sfTab = null;
      for(var i=0;i<tabs.length;i++){
        if(tabs[i].url && tabs[i].url.indexOf('stara.my.site.com') >= 0){
          sfTab = tabs[i]; break;
        }
      }
      if(!sfTab){
        // Abre o SF e aguarda
        setMsg('Abrindo SF...','inf');
        chrome.tabs.create({url: SF_URL}, function(tab){
          setTimeout(function(){
            chrome.scripting.executeScript({
              target:{tabId:tab.id},
              files:['content-sf.js']
            }, function(){
              setMsg('✅ Preenchimento iniciado na nova aba!','ok');
              btn.disabled = false;
            });
          }, 4000);
        });
      } else {
        // Ativa a aba e injeta
        chrome.tabs.update(sfTab.id, {active:true});
        chrome.windows.update(sfTab.windowId, {focused:true});
        chrome.scripting.executeScript({
          target:{tabId:sfTab.id},
          files:['content-sf.js']
        }, function(){
          setMsg('✅ Preenchendo na aba do SF!','ok');
          btn.disabled = false;
        });
      }
    });
  };
});
