// JuliomaqSF v1.2 — content-sf.js
// Preenche campos do Salesforce Experience Cloud (LWC)
console.log('[JuliomaqSF] content-sf.js ativo');

var _jmBanner = null;
var _setStatus = null;

// ── Utilitários ───────────────────────────────────────────────

function aguardar(ms){ return new Promise(function(r){ setTimeout(r,ms); }); }

// Espera um seletor aparecer no DOM (polling, max ms)
function esperarEl(sel, maxMs){
  maxMs = maxMs||8000;
  return new Promise(function(resolve,reject){
    var start=Date.now();
    (function check(){
      var el=document.querySelector(sel);
      if(el) return resolve(el);
      if(Date.now()-start>maxMs) return reject('timeout:'+sel);
      setTimeout(check,200);
    })();
  });
}

// Espera N opções de listbox aparecerem
function esperarOpcoes(minN, maxMs){
  minN=minN||1; maxMs=maxMs||6000;
  return new Promise(function(resolve,reject){
    var start=Date.now();
    (function check(){
      var opts=document.querySelectorAll('[role="option"]');
      if(opts.length>=minN) return resolve(opts);
      if(Date.now()-start>maxMs) return reject('timeout opcoes');
      setTimeout(check,200);
    })();
  });
}

// Dispara eventos nativos que o LWC detecta
function dispararEventos(el, eventos){
  eventos.forEach(function(tipo){
    try{ el.dispatchEvent(new Event(tipo,{bubbles:true,cancelable:true})); }catch(e){}
    try{ el.dispatchEvent(new InputEvent(tipo,{bubbles:true,cancelable:true,inputType:'insertText'})); }catch(e){}
  });
}

// Preenche input com setter nativo (bypassa React/LWC)
function setValorInput(el, valor){
  var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
  setter.call(el,valor);
  dispararEventos(el,['focus','keydown','keypress','input','keyup','change','blur']);
}

// Preenche textarea com setter nativo
function setValorTextarea(el, valor){
  var setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;
  setter.call(el,valor);
  dispararEventos(el,['focus','input','change','blur']);
}

// Simula digitação letra a letra (necessário para lookups do SF)
async function digitarDevagar(el, texto){
  el.focus();
  el.click();
  await aguardar(200);
  // Limpa campo
  var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
  setter.call(el,'');
  dispararEventos(el,['input','change']);
  await aguardar(200);
  // Digita devagar
  for(var i=0;i<texto.length;i++){
    var ch=texto[i];
    setter.call(el,texto.substring(0,i+1));
    el.dispatchEvent(new KeyboardEvent('keydown',{key:ch,bubbles:true}));
    el.dispatchEvent(new InputEvent('input',{data:ch,inputType:'insertText',bubbles:true}));
    el.dispatchEvent(new KeyboardEvent('keyup',{key:ch,bubbles:true}));
    await aguardar(60);
  }
  el.dispatchEvent(new Event('change',{bubbles:true}));
}

// ── Banner ────────────────────────────────────────────────────
function criarBanner(msg){
  if(_jmBanner) _jmBanner.remove();
  var b=document.createElement('div');
  b.id='jm-banner';
  b.style.cssText='position:fixed;top:0;left:0;right:0;z-index:2147483647;'
    +'background:linear-gradient(135deg,#1565c0,#0d47a1);'
    +'color:#fff;padding:10px 18px;font-family:Arial,sans-serif;font-size:13px;'
    +'display:flex;align-items:center;gap:12px;box-shadow:0 3px 12px rgba(0,0,0,.35)';
  b.innerHTML='<span style="font-size:18px">☁️</span>'
    +'<b>JuliomaqSF</b>'
    +'<span id="jm-st" style="flex:1">'+msg+'</span>'
    +'<button id="jm-close" style="background:rgba(255,255,255,.2);border:none;'
    +'color:#fff;border-radius:20px;padding:3px 12px;cursor:pointer;font-size:12px">✕</button>';
  document.body.appendChild(b);
  document.body.style.paddingTop='46px';
  document.getElementById('jm-close').onclick=function(){ b.remove(); document.body.style.paddingTop=''; };
  _jmBanner=b;
  _setStatus=function(txt,cor){
    var el=document.getElementById('jm-st');
    if(el) el.textContent=txt;
    if(cor) b.style.background=cor;
  };
}

// ── Preencher combobox SF (Sub Tipos, Origem, Status) ─────────
async function preencherCombobox(ariaLabel, valor){
  if(!valor) return {ok:false,msg:'sem valor'};
  try{
    // Encontra o botão do combobox pelo aria-label
    var btn=document.querySelector('button[aria-label="'+ariaLabel+'"]');
    if(!btn) return {ok:false,msg:'botão não encontrado: '+ariaLabel};

    btn.click();
    await aguardar(600);

    // Aguarda opções aparecerem
    var opts=await esperarOpcoes(1,4000);
    var valorLower=valor.toLowerCase();
    var alvo=null;

    // Busca match exato primeiro, depois parcial
    for(var i=0;i<opts.length;i++){
      var txt=opts[i].textContent.trim();
      if(txt.toLowerCase()===valorLower){ alvo=opts[i]; break; }
    }
    if(!alvo){
      for(var i=0;i<opts.length;i++){
        var txt=opts[i].textContent.trim();
        if(txt.toLowerCase().indexOf(valorLower)>=0){ alvo=opts[i]; break; }
      }
    }
    if(!alvo){
      document.body.click();
      return {ok:false,msg:'opção não encontrada: '+valor};
    }
    alvo.click();
    await aguardar(400);
    return {ok:true};
  }catch(e){
    return {ok:false,msg:String(e)};
  }
}

// ── Preencher lookup SF (Conta, Contato, Ativo, Operador) ─────
async function preencherLookup(ariaLabel, valor, primeirasPalavras){
  if(!valor) return {ok:false,msg:'sem valor'};
  try{
    var inp=document.querySelector('input[aria-label="'+ariaLabel+'"]');
    if(!inp) return {ok:false,msg:'input não encontrado: '+ariaLabel};

    // Digita só as primeiras palavras para acionar a busca do SF
    var busca=primeirasPalavras || valor.split(' ').slice(0,3).join(' ');
    await digitarDevagar(inp, busca);

    // Aguarda sugestões do servidor
    await aguardar(2000);
    var opts=document.querySelectorAll('[role="option"]');
    if(opts.length===0) return {ok:false,msg:'sem sugestões para: '+busca};

    // Tenta achar o match mais próximo
    var valorLower=valor.toLowerCase();
    var alvo=opts[0]; // padrão: primeira sugestão
    for(var i=0;i<opts.length;i++){
      var txt=opts[i].textContent.trim().toLowerCase();
      if(txt.indexOf(valorLower)>=0 || valorLower.indexOf(txt.split(' ')[0])>=0){
        alvo=opts[i]; break;
      }
    }
    alvo.click();
    await aguardar(800);
    return {ok:true};
  }catch(e){
    return {ok:false,msg:String(e)};
  }
}

// ── Preenchimento principal ───────────────────────────────────
async function preencherFormulario(d){
  criarBanner('Aguardando formulário carregar...');
  await aguardar(3000);

  var erros=[], ok=[];

  // 1. Assunto (input simples)
  if(d.assunto){
    _setStatus('Preenchendo assunto...');
    var el=await esperarEl('input[name="Subject"]',5000).catch(function(){return null;});
    if(el){ setValorInput(el,d.assunto); ok.push('Assunto'); }
    else erros.push('Assunto');
  }

  // 2. Nº Série Topper
  if(d.serie){
    var el=document.querySelector('input[name="NumeroSerieTopper__c"]');
    if(el){ setValorInput(el,d.serie); ok.push('Série'); }
    else erros.push('Série');
  }

  // 3. Descrição Máquina
  if(d.descMaquina){
    var el=document.querySelector('input[name="Descri_o_Maquina__c"]');
    if(el){ setValorInput(el,d.descMaquina); ok.push('Desc.Máquina'); }
    else erros.push('Desc.Máquina');
  }

  // 4. Reclamação (primeiro textarea visível)
  if(d.reclamacao){
    _setStatus('Preenchendo reclamação...');
    var tas=document.querySelectorAll('textarea');
    var preencheu=false;
    for(var i=0;i<tas.length;i++){
      if(tas[i].offsetParent!==null){
        setValorTextarea(tas[i],d.reclamacao);
        ok.push('Reclamação'); preencheu=true; break;
      }
    }
    if(!preencheu) erros.push('Reclamação');
  }

  // 5. Comboboxes
  _setStatus('Preenchendo tipo de serviço...');
  if(d.subTipo){
    var r=await preencherCombobox('Sub Tipos de Serviços Oficina',d.subTipo);
    r.ok ? ok.push('Sub Tipos') : erros.push('Sub Tipos ('+r.msg+')');
  }
  if(d.origem){
    var r=await preencherCombobox('Origem do caso',d.origem);
    r.ok ? ok.push('Origem') : erros.push('Origem ('+r.msg+')');
  }

  // 6. Lookups
  if(d.conta){
    _setStatus('Buscando conta: '+d.conta.split(' ')[0]+'...');
    var r=await preencherLookup('Nome da conta',d.conta);
    r.ok ? ok.push('Conta') : erros.push('Conta ('+r.msg+')');
    await aguardar(1000); // aguarda contato auto-preencher
  }
  if(d.contato){
    var ctInp=document.querySelector('input[aria-label="Nome do Contato"]');
    if(!ctInp||!ctInp.value){
      _setStatus('Buscando contato...');
      var r=await preencherLookup('Nome do Contato',d.contato);
      r.ok ? ok.push('Contato') : erros.push('Contato ('+r.msg+')');
    } else ok.push('Contato (auto)');
  }
  if(d.serie){
    _setStatus('Buscando ativo: '+d.serie+'...');
    var r=await preencherLookup('Ativo',d.serie,d.serie);
    r.ok ? ok.push('Ativo') : erros.push('Ativo ('+r.msg+')');
  }
  if(d.operador){
    var r=await preencherLookup('Nome do Operador',d.operador);
    r.ok ? ok.push('Operador') : erros.push('Operador ('+r.msg+')');
  }

  // 7. Resultado final
  var msg='✅ '+ok.length+' campos preenchidos!';
  var cor='linear-gradient(135deg,#2e7d32,#1b5e20)';
  if(erros.length>0){
    msg+='  ⚠️ Verificar: '+erros.map(function(e){ return e.split(' ')[0]; }).join(', ');
    cor='linear-gradient(135deg,#e65100,#bf360c)';
  }
  _setStatus(msg,cor);
  console.log('[JuliomaqSF] OK:',ok,'Erros:',erros);

  // Limpa dados do storage
  chrome.storage.local.remove(['sfData','sfTs']);
}

// ── Entrada ───────────────────────────────────────────────────
chrome.storage.local.get(['sfData','sfTs'],function(r){
  var fresh=r.sfTs&&(Date.now()-r.sfTs)<15*60*1000;
  if(!fresh||!r.sfData){
    console.log('[JuliomaqSF] Sem dados no storage');
    return;
  }
  preencherFormulario(r.sfData);
});
