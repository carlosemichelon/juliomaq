// Roda na página do Juliomaq (carlosemichelon.github.io/juliomaq)
// Escuta postMessage de _sfSalvarDadosSheet() e guarda no chrome.storage

console.log('[JuliomaqSF] content-gas.js ativo em:', window.location.href);

window.addEventListener('message', function(ev){
  if(!ev.data || ev.data.type !== 'JULIOMAQ_SF_CASE') return;

  console.log('[JuliomaqSF] Dados recebidos via postMessage:', ev.data.dados);

  // Guarda diretamente no chrome.storage (sem precisar de background)
  chrome.storage.local.set({
    sfData: ev.data.dados,
    sfTs:   Date.now()
  }, function(){
    console.log('[JuliomaqSF] Dados salvos no storage com sucesso');
  });
}, false);
